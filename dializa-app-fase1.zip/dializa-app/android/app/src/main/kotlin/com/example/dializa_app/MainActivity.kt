package com.example.dializa_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
